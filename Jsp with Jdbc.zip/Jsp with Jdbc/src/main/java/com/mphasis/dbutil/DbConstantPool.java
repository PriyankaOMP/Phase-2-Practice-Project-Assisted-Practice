package com.mphasis.dbutil;

public class DbConstantPool {
	public static final String DRIVER_CLASS="com.mysql.cj.jdbc.Driver";
	public static final String DB_URL="jdbc:mysql://localhost:3306/db3";
	public static final String USERNAME="root";
	public static final String PASSWORD="Dsql@0727*jha";

}
